# iStat Menus 4 Puppet Module for Boxen

Requires the `boxen` puppet module.

## Usage

```puppet
include istatmenus4
```

## Developing

Write code.

Run `script/cibuild`.
