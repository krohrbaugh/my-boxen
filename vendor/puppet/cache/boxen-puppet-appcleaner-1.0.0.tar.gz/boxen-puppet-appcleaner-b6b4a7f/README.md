# Install AppCleaner Puppet Module for Boxen

AppCleaner is a small application which allows you to thoroughly uninstall unwanted apps.


See http://www.freemacsoft.net/appcleaner/ for more. 

## Usage

```include appcleaner```


## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
