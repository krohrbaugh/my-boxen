# ZSH Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-zsh.png?branch=master)](https://travis-ci.org/boxen/puppet-zsh)

Installs zsh and makes it your default shell. For justice.

## Usage

```puppet
include zsh
```

# Required Puppet Modules

* `boxen`
* `homebrew`
* `osx`
* `stdlib`

## Developing

Write code.

Write code. Run `script/cibuild`. Send Pull Requests.

